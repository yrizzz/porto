import type { MetaFunction } from "@remix-run/node";
import vscodeImgLogo from "../../public/vscode.png";
import { Image, Button } from "@heroui/react";
export const meta: MetaFunction = () => {
  return [
    { title: "New Remix App" },
    { name: "description", content: "Welcome to Remix!" },
  ];
};

export default function Index() {
  return (
    <main className="flex min-h-screen flex-col container mx-auto">
      <section className="py-4">
        <div className="grid grid-cols-1 lg:grid-cols-12">
          <div className="col-span-7 flex flex-col justify-center border-1">
            <h1 className="text-4xl mb-4 font-extrabold">
              Welcome to my Website
            </h1>
            <p>My name is Aris Edy Handoko</p>
            <h1 className="animate-typing overflow-hidden whitespace-nowrap border-r-4 border-r-white pr-5 text-2xl font-bold">Hello World</h1>
            <div className="flex flex-wrap gap-2 mt-3">
              <Button
                className="bg-gradient-to-tr from-cyan-500 to-indigo-500 text-white shadow-lg"
                radius="sm">
                Buy me coffe
              </Button>
              <Button
                color="primary" variant="bordered"
                radius="sm">
                Project
              </Button>
            </div>
          </div>
          <div className="col-span-5 flex flex-col justify-center border-1">
            <center>
              <div className="rounded-full lg:w-[300px] lg:h-[300px] sm:w-[200px] sm:h-[200px] sm:mt-4 lg:mt-0 border-1 flex flex-col justify-center items-center">
                <Image
                  alt="VSCode Logo"
                  src={vscodeImgLogo}
                  width={200}
                  height={200}
                  loading="eager"
                  className="flex flex-col justify-center"
                  isBlurred
                />
              </div>
            </center>
          </div>
        </div>
      </section>
    </main>
  );
}
