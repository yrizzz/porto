import type { LinksFunction } from "@remix-run/node";
import {
  Links,
  Meta,
  Scripts,
  Outlet,
  ScrollRestoration
} from "@remix-run/react";

import "./tailwind.css";
import Header from './components/header'
import { HeroUIProvider } from "@heroui/react";
import { ThemeProvider as NextThemesProvider } from "next-themes";

export const links: LinksFunction = () => [
  { rel: "preconnect", href: "https://fonts.googleapis.com" },
  {
    rel: "preconnect",
    href: "https://fonts.gstatic.com",
    crossOrigin: "anonymous",
  },
  {
    rel: "stylesheet",
    href: "https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap",
  },
];

export default function App() {
  return (
    <html lang="en" suppressHydrationWarning={true}>
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <Meta />
        <Links />
      </head>
      <body>
        <HeroUIProvider>
          <NextThemesProvider attribute="class" defaultTheme="light">
            <Header />
            <div className="container mx-auto px-4">
              <Outlet />
            </div>
            <ScrollRestoration />
            <Scripts />
          </NextThemesProvider>
        </HeroUIProvider >
      </body>
    </html>
  );
}
